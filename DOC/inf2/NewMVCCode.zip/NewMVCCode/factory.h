#ifndef FACTORY_H
#define FACTORY_H

#include "data.h"
#include "logic.h"
#include "inputview.h"
#include "outputview.h"

#define NBROV 5

class Factory
{
public:
    Factory();
    ~Factory();
    void build();
private:
    Data* data;
    Logic* logic;
    OutputView** v1;
    InputView* v2;
};

#endif // FACTORY_H
