#ifndef DATA_H
#define DATA_H

#include "observer.h"
#include <Qpainter>

class Data
{
    class Circle
    {
    public:
        Circle(Data* host);
        ~Circle();
        void draw(QPainter* p);
        void setXY(int x, int y);
        int getX();
        int getY();
    private:
        int x;
        int y;
        Data* host;
    };

public:
    Data();
    void subscribe(Observer* obs);
    void notifyAll();
    Circle *getCircle();
    void setCircle();

private:
    Observer** observers;
    int obsCnt;
    Circle* c;
};

#endif // DATA_H
