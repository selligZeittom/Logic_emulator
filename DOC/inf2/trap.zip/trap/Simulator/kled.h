/* This file is part of the KDE libraries
    Copyright (C) 1998 Jörg Habenicht (j.habenicht@europemail.com)

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public License
    along with this library; see the file COPYING.LIB.  If not, write to
    the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor,
    Boston, MA 02110-1301, USA.
*/

#ifndef KLED_H
#define KLED_H

#include <QWidget>

class QColor;

class KLed : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(State state READ state WRITE setState)
    Q_PROPERTY(Shape shape READ shape WRITE setShape)
    Q_PROPERTY(Look look READ look WRITE setLook)
    Q_PROPERTY(QColor color READ color WRITE setColor)
    Q_PROPERTY(int darkFactor READ darkFactor WRITE setDarkFactor)

public:

    enum State { Off, On };
    Q_ENUM(State)


    enum Shape { Rectangular, Circular };
    Q_ENUM(Shape)


    enum Look  { Flat, Raised, Sunken };
    Q_ENUM(Look)


    explicit KLed(QWidget *parent = nullptr);

    explicit KLed(const QColor &color, QWidget *parent = nullptr);

    KLed(const QColor &color, KLed::State state, KLed::Look look, KLed::Shape shape,
         QWidget *parent = nullptr);

    virtual ~KLed();

    QColor color() const;

    State state() const;

    Look look() const;

    Shape shape() const;

    int darkFactor() const;

    void setColor(const QColor &color);

    void setState(State state);

    void setLook(Look look);

    void setShape(Shape shape);

    void setDarkFactor(int darkFactor);

    QSize sizeHint() const Q_DECL_OVERRIDE;
    QSize minimumSizeHint() const Q_DECL_OVERRIDE;

public Q_SLOTS:

    void toggle();

    void on();

    void off();

Q_SIGNALS:
    void onchanged(int state);

protected:
    void paintEvent(QPaintEvent *) Q_DECL_OVERRIDE;
    void resizeEvent(QResizeEvent *) Q_DECL_OVERRIDE;

    void updateCachedPixmap();

private:
    class Private;
    Private *const d;

    void updateAccessibleName();
};

#endif
