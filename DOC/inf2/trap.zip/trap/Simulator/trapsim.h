/*
 * Class TrapSim
 * This class is the trap simulator.
 * It uses the QT library n order to optically
 * and soundwise represent a trap system.
 *
 */


#ifndef SIMULATOR_H
#define SIMULATOR_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include "kled.h"

#include "../UI/buttonmanager.h"
#include "../Alert/photosensor.h"
#include "../Interfaces/itrap.h"

class TrapSim : public QMainWindow, public ITrap
{
    Q_OBJECT

public:
    TrapSim(QWidget *parent = 0);
    virtual ~TrapSim();
    void initialize();
    void initRelations(ButtonManager* p1, PhotoSensor* p2);
    KLed* getLed(int p1);
    QMediaPlayer* getSiren();
    KLed* getLock();

private:
    ButtonManager* bMan;
    PhotoSensor* phSens;
    int trapIsLocked;
    void lockTrap();

private:
    QPushButton* b1;
    QPushButton* b2;
    QPushButton* b3;
    QPushButton* b4;
    QPushButton* bOnOff;
    QPushButton* bUnlock;

    QPushButton* ps;

    KLed* ledState;
    KLed* ledOnOff;
    KLed* ledLock;
    QLabel* lblState;
    QLabel* lblOnOff;
    QLabel* lblLock;

    QMediaPlayer* siren;
    QMediaPlaylist* sounds;

private slots:
    void onB1();
    void onB2();
    void onB3();
    void onB4();
    void onBOnOff();
    void onPS();
    void onOnOffEnable(int p1);
    void onLockUnlock();


};

#endif // SIMULATOR_H
