#include "trapsim.h"
#include <QDebug>

TrapSim::TrapSim(QWidget *parent)
    : QMainWindow(parent)
{
    this->setGeometry(100,100,400,250);
    b1 = new QPushButton(this);
    b2 = new QPushButton(this);
    b3 = new QPushButton(this);
    b4 = new QPushButton(this);
    bOnOff = new QPushButton(this);
    bUnlock = new QPushButton(this);

    bOnOff->setIcon(QIcon(QPixmap(":/Simulator/onoff.png")));
    bOnOff->setIconSize(QSize(50, 50));
    bOnOff->setStyleSheet("QPushButton{border: none;outline: none;}");

    bUnlock->setIconSize(QSize(50, 50));
    bUnlock->setStyleSheet("QPushButton{border: none;outline: none;}");

    ps = new QPushButton(this);

    ledState = new KLed(QColor(255,0,0),KLed::Off,KLed::Raised,KLed::Circular,this);
    ledOnOff = new KLed(QColor(0,255,0),KLed::Off,KLed::Raised,KLed::Circular,this);
    ledLock  = new KLed(QColor(255,0,0),KLed::Off,KLed::Raised,KLed::Circular,this);
    lblState = new QLabel(QString("State"),this);
    lblOnOff = new QLabel(QString("Power"),this);
    lblLock = new QLabel(QString("no ON/OFF"),this);

    b1->setText("Arm");
    b1->setGeometry(10,20,100,50);
    b2->setText("Disarm");
    b2->setGeometry(10,70,100,50);
    b3->setText("Reset");
    b3->setGeometry(10,120,100,50);
    b4->setText("Test");
    b4->setGeometry(10,170,100,50);

    bOnOff->setGeometry(290,170,100,50);
    bUnlock->setGeometry(120,20,50,200);

    ps->setText("Interrupt");
    ps->setGeometry(290,120,100,50);

    //Tooltips
    b1->setToolTip("arm trap");
    b2->setToolTip("disarm trap");
    b3->setToolTip("reset warning/alert state to armed state");
    b4->setToolTip("test trap");

    bOnOff->setToolTip("switch trap on/off");
    bUnlock->setToolTip("allow / disallow access to trap");

    ps->setToolTip("simulate photosensor interruption");

    ledOnOff->setToolTip("indicates if trap is on/off");
    ledState->setToolTip("off: idle, blink slow: armed, blink fast: warning, on: alert");
    ledLock->setToolTip("on: ON/OFF disabled");

    ledOnOff->setGeometry(350,20,30,30);
    ledState->setGeometry(350,50,30,30);
    ledLock->setGeometry(350,80,30,30);
    lblOnOff->setGeometry(270,20,70,30);
    lblState->setGeometry(270,50,70,30);
    lblLock->setGeometry(270,80,70,30);


    sounds = new QMediaPlaylist();
    sounds->addMedia(QUrl("qrc:/Simulator/redalert.mp3"));
    sounds->addMedia(QUrl("qrc:/Simulator/warning.mp3"));
    sounds->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);

    siren = new QMediaPlayer();
    siren->setPlaylist(sounds);

    connect(b1,SIGNAL(clicked()),this,SLOT(onB1()));
    connect(b2,SIGNAL(clicked()),this,SLOT(onB2()));
    connect(b3,SIGNAL(clicked()),this,SLOT(onB3()));
    connect(b4,SIGNAL(clicked()),this,SLOT(onB4()));
    connect(bOnOff,SIGNAL(clicked()),this,SLOT(onBOnOff()));
    connect(ps,SIGNAL(clicked()),this,SLOT(onPS()));
    connect(ledLock,SIGNAL(onchanged(int)),this,SLOT(onOnOffEnable(int)));
    connect(bUnlock,SIGNAL(clicked()),this,SLOT(onLockUnlock()));

    bMan = nullptr;
    phSens = nullptr;

    trapIsLocked = 1;
    lockTrap();
    bMan = nullptr;
    phSens = nullptr;
    siren->stop();
    ledLock->off();
    ledOnOff->off();
    ledState->off();
}

TrapSim::~TrapSim()
{
    delete b1;
    delete b2;
    delete b3;
    delete b4;

    delete ledState;
    delete ledOnOff;
    delete ledLock;
}

void TrapSim::initRelations(ButtonManager *p1,
                            PhotoSensor* p2)
{
    bMan=p1;
    phSens = p2;
    show();
}

KLed *TrapSim::getLed(int p1)
{
    KLed* retval = nullptr;
    switch (p1)
    {
        case 1:
        retval = ledOnOff;
        break;
        case 2:
        retval = ledState;
        break;
        default:
        retval = nullptr;
    }
    return retval;
}

QMediaPlayer *TrapSim::getSiren()
{
    return siren;
}

KLed *TrapSim::getLock()
{
    return ledLock;
}

void TrapSim::onB1()
{
    bMan->press(1);
}

void TrapSim::onB2()
{
    bMan->press(2);
}

void TrapSim::onB3()
{
    bMan->press(3);
}

void TrapSim::onB4()
{
    bMan->press(4);
}

void TrapSim::onBOnOff()
{
    bMan->press(5);
}

void TrapSim::onPS()
{
    phSens->interrupt();
}

void TrapSim::onOnOffEnable(int p1)
{
    if (p1)
        bOnOff->setEnabled(false);
    else
        bOnOff->setEnabled(true);
}

void TrapSim::onLockUnlock()
{
    trapIsLocked = trapIsLocked==1?0:1;
    lockTrap();
}

void TrapSim::lockTrap()
{
    if (trapIsLocked)
        bUnlock->setIcon(QIcon(QPixmap(":/Simulator/lockclosed.png")));
    else
        bUnlock->setIcon(QIcon(QPixmap(":/Simulator/lockopen.png")));

    bool en = trapIsLocked==1?false:true;
    b1->setVisible(en);
    b2->setVisible(en);
    b3->setVisible(en);
    b4->setVisible(en);
}
