/*
 * Interface ILrd
 * This interface provides a method setLedState
 * for classes that have to deal with leds. The
 * parameters passed is the id of the led and
 * whether it has to be set on or off.
 *
 */


#ifndef ILED_H
#define ILED_H

class ILED
{
public:
    virtual void setLedState(int p1, int p2) = 0;
};

#endif // ILED_H
