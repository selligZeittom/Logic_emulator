/*
 * Interface ISiren
 * This interface provides a method setSiren
 * for classes that have to deal with sirens. The
 * parameter passed is the type of sound. You
 * can choose between a warning sound or an alert sound.
 *
 */


#ifndef ISIREN_H
#define ISIREN_H


class ISiren
{
public:
    virtual void setSiren(int p1) = 0;
};

#endif // ISIREN_H
