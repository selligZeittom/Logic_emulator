/*
 * Interface IKey
 * This interface provides a method onKeyPressed
 * for classes that have to deal with keys. The
 * parameter passed is the id of the key.
 *
 */

#ifndef IKEY_H
#define IKEY_H

class IKey
{
public:
    virtual void onKeyPressed(int p1) = 0;
};

#endif // IKEY_H
