/*
 * Interface ILock
 * This interface provides a method setLock
 * for classes that have to deal with a relay.
 * The parameter passed is wheter the relay
 * has to be closed or openend.
 *
 */


#ifndef ILOCK_H
#define ILOCK_H


class ILock
{
public:
    virtual void setLock(int p1) = 0;
};

#endif // ILOCK_H
