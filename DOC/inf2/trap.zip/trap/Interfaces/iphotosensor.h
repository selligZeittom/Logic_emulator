/*
 * Interface IPhotoSensor
 * This interface provides a method onActivated
 * for classes that have to deal with photosensors.
 * This method is called if the photosensor is
 * activated.
 *
 */


#ifndef IPHOTOSENSOR_H
#define IPHOTOSENSOR_H


class IPhotoSensor
{
public:
    virtual void onActivated() = 0;
};

#endif // IPHOTOSENSOR_H
