/*
 * Interface ITrap
 * This interface provides methods for classes
 * that have to deal with the trap system. It
 * provides a method in order to gain access to
 * the sound system, a method in order to gain access
 * to leds and a method in order to gain access to
 * a relay. Trapsystems have to implement this interface.
 * Classes that interact with a trap system will count
 * on the presence of these methods.
 *
 */


#ifndef ITRAP_H
#define ITRAP_H

class KLed;
class QMediaPlayer;

class ITrap
{
public:
    virtual KLed* getLed(int p1) = 0;
    virtual QMediaPlayer* getSiren() = 0;
    virtual KLed* getLock() = 0;
};

#endif // ITRAP_H
