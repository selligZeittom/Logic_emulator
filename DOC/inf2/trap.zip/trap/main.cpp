#include "XF/xf.h"
#include "factory.h"



int main(int argc, char *argv[])
{
    //create the execution framework
    XF::getInstance();

    //create a factory object
    Factory f;
    //the factory object creates all other objects
    //of the trap system
    f.create();
    //the factory connects (links) all the
    //objects according to the object diagram
    f.build();

    //run the execution framework
    XF::getInstance().exec();

    //destroy the objects of the system
    f.destroy();

    return 0;
}
