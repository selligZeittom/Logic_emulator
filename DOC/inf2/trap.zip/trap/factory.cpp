#include "factory.h"

#include "Simulator/trapsim.h"
#include "UI/buttonmanager.h"
#include "UI/ledmanager.h"
#include "UI/portuilogic.h"
#include "Alert/lock.h"
#include "Alert/photosensor.h"
#include "Alert/portalertlogic.h"
#include "Alert/siren.h"
#include "Logic/portlogicalert.h"
#include "Logic/portlogicui.h"
#include "Logic/trapcontroller.h"
#include "UI/led.h"
#include "UI/blinker.h"

Factory::Factory()
{
    //ground all pointers
    ts = nullptr;
    bm = nullptr;
    lm = nullptr;
    l1 = nullptr;
    l2 = nullptr;
    b1 = nullptr;
    pUL= nullptr;
    pLU= nullptr;
    tc = nullptr;
    pLA= nullptr;
    pAL= nullptr;
    si = nullptr;
    lk = nullptr;
    ps = nullptr;
}

Factory::~Factory()
{

}

void Factory::create()
{
    //create all objects
    ts = new TrapSim();
    bm = new ButtonManager();
    lm = new LEDManager();
    l1 = new Led(1);
    l2 = new Led(2);
    b1 = new Blinker();
    pUL= new PortUILogic();
    pLU= new PortLogicUI();
    tc = new TrapController();
    pLA= new PortLogicAlert();
    pAL= new PortAlertLogic();
    si = new Siren();
    lk = new Lock();
    ps = new PhotoSensor();
}

void Factory::destroy()
{
    //delete all objects
    delete ts ;
    delete bm ;
    delete lm ;
    delete l1;
    delete l2;
    delete b1;
    delete pUL;
    delete pLU;
    delete tc ;
    delete pLA;
    delete pAL;
    delete si ;
    delete lk ;
    delete ps ;
}

void Factory::build()
{
    //link all the objects according to the system model
    pUL->initRelations(pLU, lm);
    pLU->initRelations(pUL,tc);
     bm->initRelations(pUL);
     lm->initRelations(l1,l2,b1);
     l1->initRelations(ts);
     l2->initRelations(ts);
     b1->initRelations(l2);
     tc->initRelations(pLU,pLA);
    pAL->initRelations(pLA,si,lk);
    pLA->initRelations(pAL,tc);
     ps->initRelations(pAL);
     si->initRelations(ts);
     lk->initRelations(ts);
     ts->initRelations(bm, ps);
}


