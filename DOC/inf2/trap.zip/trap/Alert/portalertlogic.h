/*
 * Class ProtAlertLogic
 * This class is the gateway to the logic pakage.
 * It provides interfaces for the usage of the
 * siren, the lock and the photosensor.
 * It has a connection to it's peer port PortLogicAlert
 * as well as conections to the Siren and the Lock class.
 * The Photosensor and it's peer port are connected to it,
 * but the port does not know this.
 *
 */

#ifndef PORTALERTLOGIC_H
#define PORTALERTLOGIC_H

#include "Interfaces/iphotosensor.h"
#include "Interfaces/ilock.h"
#include "Interfaces/isiren.h"

class PortLogicAlert;
class Siren;
class Lock;


class PortAlertLogic : public IPhotoSensor, public ILock, public ISiren
{
public:
    PortAlertLogic();
    virtual ~PortAlertLogic();
    virtual void onActivated();
    virtual void setSiren(int p1);
    virtual void setLock(int p1);
    void initRelations(PortLogicAlert* p1,
                       Siren* p2,
                       Lock* p3);
private:
    PortLogicAlert* theLogic;
    Siren* theSiren;
    Lock* theLock;
};

#endif // PORTALERTLOGIC_H
