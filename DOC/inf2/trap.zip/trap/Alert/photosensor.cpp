#include "photosensor.h"
#include "portalertlogic.h"

PhotoSensor::PhotoSensor()
{
    theLogic = nullptr;
}

void PhotoSensor::interrupt()
{
    theLogic->onActivated();
}

void PhotoSensor::initRelations(PortAlertLogic* p1)
{
    theLogic = p1;
}
