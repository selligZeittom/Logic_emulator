#include "portalertlogic.h"
#include "Logic/portlogicalert.h"
#include "siren.h"
#include "lock.h"


PortAlertLogic::PortAlertLogic()
{
    theLogic = nullptr;
    theSiren = nullptr;
    theLock  = nullptr;
}

PortAlertLogic::~PortAlertLogic()
{

}

void PortAlertLogic::onActivated()
{
    theLogic->onActivated();
}

void PortAlertLogic::setSiren(int p1)
{

    theSiren->setSiren(p1);
}

void PortAlertLogic::setLock(int p1)
{
    theLock->setLock(p1);
}

void PortAlertLogic::initRelations(PortLogicAlert* p1,
                                   Siren* p2,
                                   Lock* p3)
{
    theLogic = p1;
    theSiren = p2;
    theLock  = p3;
}
