#include "lock.h"
#include "Interfaces/itrap.h"
#include "Simulator/kled.h"

Lock::Lock()
{
    trap = nullptr;
}

Lock::~Lock()
{

}

void Lock::setLock(int p1)
{
    if (p1)
        trap->getLock()->on();
    else
        trap->getLock()->off();
}

void Lock::initRelations(ITrap* p1)
{
    trap = p1;
}
