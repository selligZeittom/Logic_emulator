/*
 * Class Photosensor
 * This class implements the photosensor in
 * the trap system. It provides the callback method
 * interrupt to the trap system. The trap
 * system calls this method when the photosensor
 * is interrupted. The photosensor class is
 * connected to port towards the logic by means of
 * a PortAlertLogic pointer. The photosensor is not
 * connected to the trap system.
 */

#ifndef PHOTOSENSOR_H
#define PHOTOSENSOR_H

class PortAlertLogic;

class PhotoSensor
{
public:
    PhotoSensor();
    void interrupt();
    void initRelations(PortAlertLogic* p1);
private:
    PortAlertLogic* theLogic;
};

#endif // PHOTOSENSOR_H
