/*
 * Class Siren
 * The siren class represents the siren in the
 * trap system. The siren can play either an
 * warning sound or an alert sound. It
 * implements the ISiren interface which lets
 * choose one of this sounds by parameter.
 * The siren has an ITrap pointer connecting
 * it to the trap system.
 *
 */

#ifndef SIREN_H
#define SIREN_H

#include "Interfaces/isiren.h"

class ITrap;

class Siren : public ISiren
{
public:
    Siren();
    virtual ~Siren();
    void setSiren(int p1);
    void initRelations(ITrap* p1);
private:
    ITrap* trap;

};

#endif // SIREN_H
