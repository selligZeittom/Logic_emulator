#include "siren.h"
#include "Interfaces/itrap.h"
#include <QDebug>
#include <QMediaPlayer>
#include <QMediaPlaylist>

Siren::Siren()
{
    trap = nullptr;
}

Siren::~Siren()
{

}

void Siren::setSiren(int p1)
{
    switch (p1)
    {
    case 1:
        trap->getSiren()->playlist()->setCurrentIndex(1);
        trap->getSiren()->setVolume(50);
        trap->getSiren()->play();
        break;
    case 2:
        trap->getSiren()->playlist()->setCurrentIndex(2);
        trap->getSiren()->setVolume(100);
        trap->getSiren()->play();
        break;
    default:
        trap->getSiren()->stop();
    }
}

void Siren::initRelations(ITrap* p1)
{
    trap = p1;
}


