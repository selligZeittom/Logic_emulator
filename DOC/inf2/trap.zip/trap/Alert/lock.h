/*
 * Class Lock
 * This class represents the transistor
 * that shortens the on off switch during
 * warning and alert state
 * It implements the ILock interface in
 * order to provide the setLock method.
 * It also has an ITrap pointer towards
 * the trap system.
 *
 * */

#ifndef LOCK_H
#define LOCK_H

#include "Interfaces/ilock.h"

class ITrap;

class Lock : public ILock
{

public:
    Lock();
    virtual ~Lock();
    void setLock(int p1);
    void initRelations(ITrap* p1);
private:
    ITrap* trap;
};

#endif // LOCK_H
