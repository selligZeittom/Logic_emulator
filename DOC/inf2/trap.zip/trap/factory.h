#ifndef FACTORY_H
#define FACTORY_H

class TrapSim;

class Lock;
class Siren;
class PhotoSensor;

class ButtonManager;
class LEDManager;
class Led;
class Blinker;

class PortAlertLogic;
class PortLogicAlert;
class PortUILogic;
class PortLogicUI;

class TrapController;

class Factory
{

public:
    Factory();
    virtual ~Factory();
    //creation method
    void create();
    //build method
    void build();
    //destroy objects
    void destroy();

private:
    //all objects of the system
    TrapSim* ts;
    ButtonManager* bm;
    LEDManager* lm;
    Led* l1;
    Led* l2;
    Blinker* b1;
    PortUILogic* pUL;
    PortLogicUI* pLU;
    TrapController* tc;
    PortLogicAlert* pLA;
    PortAlertLogic* pAL;
    Siren* si;
    Lock* lk;
    PhotoSensor* ps;
};

#endif // FACTORY_H
