#include "portuilogic.h"
#include "Logic/portlogicui.h"
#include "ledmanager.h"


PortUILogic::PortUILogic()
{
    theLogic = nullptr;
    theLED = nullptr;
}

PortUILogic::~PortUILogic()
{

}

void PortUILogic::setLedState(int p1, int p2)
{
    theLED->setLedState(p1,p2);
}

void PortUILogic::onKeyPressed(int p1)
{
    theLogic->onKeyPressed(p1);
}

void PortUILogic::initRelations(PortLogicUI* p1, LEDManager* p2)
{
    theLogic = p1;
    theLED = p2;
}
