/*
 * Class Led
 * This class provides a very simple interface to work with
 * leds on the device layer. It has a ITrap pointer that
 * adresses the trap device.
 *
 */

#ifndef LED_H
#define LED_H

class ITrap;

class Led
{
public:
    Led(int p1);
    void initRelations(ITrap* p1);
    void on();
    void off();
private:
    int id;
    ITrap* trap;
};

#endif // LED_H
