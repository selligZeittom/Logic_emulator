#include "led.h"
#include "Interfaces/itrap.h"
#include "Simulator/kled.h"

//initialize the led id
Led::Led(int p1) : id(p1)
{
    //no trap connected yet
    trap = nullptr;
}

void Led::initRelations(ITrap * p1)
{
    trap = p1;
}

void Led::on()
{
    trap->getLed(id)->on();
}

void Led::off()
{
    trap->getLed(id)->off();
}


