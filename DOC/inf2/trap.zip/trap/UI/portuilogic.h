/*
 * Class ProtUILogic
 * This class is the gateway to the logic pakage.
 * It provides interfaces for the usage of the
 * leds and the buttons.
 * It has a connection to it's peer port PortLogicUI
 * as well as conections to the ledmanger.
 * The buttonmanager and it's peer port are connected to it,
 * but the port does not know this.
 *
 */

#ifndef PORTUILOGIC_H
#define PORTUILOGIC_H

#include "Interfaces/iled.h"
#include "Interfaces/ikey.h"

class LEDManager;
class PortLogicUI;

class PortUILogic : public ILED, public IKey
{
public:
    PortUILogic();
    virtual ~PortUILogic();
    virtual void setLedState(int p1, int p2);
    virtual void onKeyPressed(int p1);
    void initRelations(PortLogicUI* p1, LEDManager* p2);
private:
    LEDManager* theLED;
    PortLogicUI* theLogic;
};

#endif // PORTUILOGIC_H
