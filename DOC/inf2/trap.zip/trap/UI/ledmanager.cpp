#include "ledmanager.h"
#include "Interfaces/itrap.h"
#include "Simulator/kled.h"
#include "blinker.h"
#include "led.h"

LEDManager::LEDManager()
{
    ledState = nullptr;
    ledOnOff = nullptr;
    blinker = nullptr;
}

LEDManager::~LEDManager()
{

}

void LEDManager::initRelations(Led *p1, Led *p2, Blinker *p3)
{
    ledOnOff = p1;
    ledState = p2;
    blinker = p3;
}

void LEDManager::setLedState(int p1, int p2)
{
    switch (p1)
    {
    case 1:
        if (p2)
        {
            ledOnOff->on();
        }
        else
        {
            ledOnOff->off();
        }
        break;
    case 2:
        blinker->stop();
        switch (p2)
        {
        case 0:
            ledState->off();
            break;
        case 1:
            ledState->on();
            break;
        case 2:
            blinker->slow();
            break;
        case 3:
            blinker->fast();
            break;
        default:
            ;
        }
        break;
    default:
        //do nothing
        ;
    }
}
