/*
 * Class ButtonManager
 * This class manages all buttons on the devic layer
 * and provides a very simple interface to tell the application
 * layer that a button with a certain ID has been pressed.
 * It has a pointer to the port class in the same package.
 * It does not know the device that is connected.
 *
 */

#ifndef BUTTONMANAGER_H
#define BUTTONMANAGER_H

class PortUILogic;

class ButtonManager
{
public:
    ButtonManager();
    void press(int b1);
    void initRelations(PortUILogic* p1);
private:
    PortUILogic* theLogic;
};

#endif // BUTTONMANAGER_H
