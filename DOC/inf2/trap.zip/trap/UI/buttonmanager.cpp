#include "buttonmanager.h"
#include "portuilogic.h"

ButtonManager::ButtonManager()
{
    theLogic = nullptr;
}

void ButtonManager::press(int b1)
{
    theLogic->onKeyPressed(b1);
}

void ButtonManager::initRelations(PortUILogic* p1)
{
    theLogic = p1;
}
