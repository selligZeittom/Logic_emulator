/*
 * Class LEDManager
 * This class provies a very simple interfaceto the application
 * layer to deal with leads on the dvice layer:
 * parameter 1 -> led ID,
 * parameter 2 -> 0: off, 1: on, 2: blink slow, 3: blink fast
 * It has a Pointer to the state and the onoff led. It also has
 * a pointer to the blinker that will eventually blink the state led.
 * The led manager contains the logic that lets him select the led
 * directly to switch it on or off or that lets him use the blinker
 * to blink the led.
 *
 */

#ifndef LEDMANAGER_H
#define LEDMANAGER_H

#include "Interfaces/iled.h"

class PortUILogic;
class Led;
class Blinker;

class LEDManager : public ILED
{
public:
    LEDManager();
    virtual ~LEDManager();
    void initRelations(Led* p1, Led* p2, Blinker* p3);
    void setLedState(int p1, int p2);
private:
    Led* ledState;
    Led* ledOnOff;
    Blinker* blinker;
};

#endif // LEDMANAGER_H
