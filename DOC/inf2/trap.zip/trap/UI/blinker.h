/*
 * Class Blinker
 * This class is used in order to blink a led.
 * The ld is uniformly switched on and off for
 * a certain time. Two blink speeds are available:
 * slow and fast.
 * The Blinker class has a pointer to the led it
 * has to blink. Since the blinker class is reactive
 * on timeout events, it has to implement the ISM
 * interface with the processEvent method.
 * The blinkEvent is used to perform the timing.
 *
 */

#ifndef BLINKER_H
#define BLINKER_H

#include <XF/XF>

//class XFEvent;
class Led;

class Blinker : public ISM
{
public:

    Blinker();
    virtual ~Blinker();
    void initRelations(Led* p1);
    void stop();
    void slow();
    void fast();

    // ISM interface
public:
    bool processEvent(XFEvent *p1);


private:

    enum BLINKSTATE
    {
        B_ON, B_OFF
    };

    BLINKSTATE blinkState;
    Led* l;
    XFEvent* blinkEvent;

    const int SLOW_BLINK;
    const int FAST_BLINK;
    const int BT_ID;
};

#endif // BLINKER_H
