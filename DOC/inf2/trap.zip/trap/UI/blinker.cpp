#include "blinker.h"
#include "led.h"
#include "XF/xfevent.h"
#include "XF/xf.h"

//constructor to initialize the constant elements
Blinker::Blinker() : SLOW_BLINK(2000),
                     FAST_BLINK(500),
                     BT_ID(1)
{
    //initialize all other element
    l = nullptr;
    blinkState = B_ON;
    blinkEvent = new XFEvent();
    blinkEvent->setTarget(this);
    blinkEvent->setID(BT_ID);
    blinkEvent->setRepeatCount(-1);
    blinkEvent->setDoNotDelete(true);
}

//destructor to delete the blinkEvent
Blinker::~Blinker()
{
    blinkEvent->cancel();
    delete blinkEvent;
}

void Blinker::initRelations(Led* p1)
{
    l = p1;
}

void Blinker::stop()
{
    l->off();
    blinkState=B_OFF;
    blinkEvent->cancel();
}

void Blinker::slow()
{
    l->on();
    blinkState=B_ON;
    blinkEvent->setDelay(SLOW_BLINK);
    XF::getInstance().pushEvent(blinkEvent);
}

void Blinker::fast()
{
    l->on();
    blinkState=B_ON;
    blinkEvent->setDelay(FAST_BLINK);
    XF::getInstance().pushEvent(blinkEvent);
}

bool Blinker::processEvent(XFEvent *p1)
{
    //this is a kind of statemachine for the blinker
    //due to the reapeat event the SM is very simple
    //in fact, it just is a led toggler

    //if the triggering event is the blinkertimer
    if (p1->getID() == BT_ID)
    {
        //toogle the led
        if (blinkState==B_ON)
        {
            l->off();
            blinkState=B_OFF;
        }
        else
        {
            l->on();
            blinkState=B_ON;
        }
    }
    return true;
}
