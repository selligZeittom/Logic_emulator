/*
 * Class PortLogicAlert
 * This class is the gateway to the alert pakage.
 * It provides interfaces for the usage of the
 * siren, the lock and the photosensor.
 * It has a connection to it's peer port PortAlertLogic
 * as well as a conection to the controller class
 * The controller class and it's peer port are connected to it,
 * but the port does not know this.
 *
 */


#ifndef PORTLOGICALERT_H
#define PORTLOGICALERT_H

#include "Interfaces/iphotosensor.h"
#include "Interfaces/ilock.h"
#include "Interfaces/isiren.h"

class PortAlertLogic;
class TrapController;

class PortLogicAlert : public IPhotoSensor, public ILock, public ISiren
{
public:
    PortLogicAlert();
    virtual ~PortLogicAlert();
    virtual void onActivated();
    virtual void setSiren(int p1);
    virtual void setLock(int p1);
    void initRelations(PortAlertLogic* p1, TrapController* p2);
private:
    TrapController* theTC;
    PortAlertLogic* theAlert;
};

#endif // PORTLOGICALERT_H
