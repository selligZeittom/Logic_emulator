#include "trapcontroller.h"
#include "portlogicalert.h"
#include "portlogicui.h"

#include "XF/xfevent.h"
#include "XF/xf.h"

TrapController::TrapController() : WARN_TIME(10000)
{
    theUI = nullptr;
    theAlert = nullptr;

    //initialize the state tables according to the UML statemachine
    /*

      Outer Statemachine
      ==================

              |EVONFF |EVONOFF|
       -------+-------+-------+
              |       |       |
       STOFF  |STON   |       |
              |       |       |
       -------+-------+-------+
              |       |       |
       STON   |       |STOFF  |
              |       |       |
       -------+-------+-------+

      Inner Statemachine
      ==================

              |EVARM  |EVDIS  |EVTM   |EVRESET|EVTEST |EVACTI |
       -------+-------+-------+-------+-------+-------+-------+
              |       |       |       |       |       |       |
       STIDLE |STTRAP |       |       |       |STWARN |       |
              |       |       |       |       |       |       |
       -------+-------+-------+-------+-------+-------+-------+
              |       |       |       |       |       |       |
       STTRAP |       |STIDLE |       |       |       |STWARN |
              |       |       |       |       |       |       |
       -------+-------+-------+-------+-------+-------+-------+
              |       |       |       |       |       |       |
       STWARN |       |       |STALERT|STTRAP |       |       |
              |       |       |       |       |       |       |
       -------+-------+-------+-------+-------+-------+-------+
              |       |       |       |       |       |       |
       STALERT|       |       |       |STIDLE |       |       |
              |       |       |       |       |       |       |
       -------+-------+-------+-------+-------+-------+-------+
    */

    //clear both tables
    innerSM.clear();
    outerSM.clear();

    //construct the outer table
    outerSM[ST_OFF][EV_ONOFF] = ST_ON;
    outerSM[ST_ON][EV_ONOFF] = ST_OFF;

    //construct the inner table
    innerSM[ST_IDLE][EV_ARM] = ST_TRAPPING;
    innerSM[ST_IDLE][EV_TEST] = ST_WARNING;
    innerSM[ST_TRAPPING][EV_DISARM] = ST_IDLE;
    innerSM[ST_TRAPPING][EV_ACTIVATE] = ST_WARNING;
    innerSM[ST_WARNING][EV_RESET] = ST_TRAPPING;
    innerSM[ST_WARNING][EV_TIMEOUT] = ST_ALERT;
    innerSM[ST_ALERT][EV_RESET] = ST_IDLE;

    //set initial state of both state machines
    outer = ST_OFF;
    inner = ST_IDLE;

    //create a timeout event
    timeout = new XFEvent();
    timeout->setID((int)EV_TIMEOUT);
    timeout->setTarget(this);
    timeout->setDelay(WARN_TIME);
    timeout->setDoNotDelete(true);
    timeout->setRepeatCount(0);
}

TrapController::~TrapController()
{
    //destroy the timeout event
    timeout->cancel();
    delete timeout;
}

void TrapController::initRelations(PortLogicUI* p1, PortLogicAlert* p2)
{
    //connect the logic object to the port objects
    theUI = p1;
    theAlert = p2;
}

void TrapController::onOnOffKey()
{
    //generate on-off event and
    //send it to the statemachine
    XFEvent* ev = new XFEvent();
    ev->setID((int)EV_ONOFF);
    ev->setTarget(this);
    XF::getInstance().pushEvent(ev);
}

void TrapController::onArmKey()
{
    //generate arm event and
    //send it to the statemachine
    XFEvent* ev = new XFEvent();
    ev->setID((int)EV_ARM);
    ev->setTarget(this);
    XF::getInstance().pushEvent(ev);
}

void TrapController::onDisarmKey()
{
    //generate disarm event and
    //send it to the statemachine
    XFEvent* ev = new XFEvent();
    ev->setID((int)EV_DISARM);
    ev->setTarget(this);
    XF::getInstance().pushEvent(ev);
}

void TrapController::onResetKey()
{
    //generate reset event and
    //send it to the statemachine
    XFEvent* ev = new XFEvent();
    ev->setID((int)EV_RESET);
    ev->setTarget(this);
    XF::getInstance().pushEvent(ev);
}

void TrapController::onTestKey()
{
    //generate test event and
    //send it to the statemachine
    XFEvent* ev = new XFEvent();
    ev->setID((int)EV_TEST);
    ev->setTarget(this);
    XF::getInstance().pushEvent(ev);
}

void TrapController::onActivated()
{
    //generate activate event and
    //send it to the statemachine
    XFEvent* ev = new XFEvent();
    ev->setID((int)EV_ACTIVATE);
    ev->setTarget(this);
    XF::getInstance().pushEvent(ev);
}

bool TrapController::processEvent(XFEvent *p1)
{
    //we assume the event as not processed
    bool processed = false;
    if (outer == ST_ON)
    {
        //maybe the inner state machine
        //can process it
        processed = processInnerEvent(p1);
    }
    //if the event is still not processed
    if (processed == false)
    {
        //maybe the outer statemachine
        //can process it
        processed = processOuterEvent(p1);
    }
    //return the processing result
    //it may be true or false
    return processed;
}

bool TrapController::processOuterEvent(XFEvent *p1)
{
    //save the actual state
    TC_ON_OFF_STATE oldState = outer;
    //hash the new state from the state table
    TC_ON_OFF_STATE newState = outerSM[oldState][(TC_ON_OFF_EVENT)p1->getID()];
    //if the hash table found a new state
    if (newState != ST_ON_OFF_NONE)
    {
        //save the new state
        outer = newState;
    }
    //we do not know if the event will be processed
    bool retVal = false;

    if (outer != oldState)
    {
        //the event will be processed
        retVal = true;

        //do the eventual onexit-action of the old state
        switch (oldState)
        {
        case ST_ON:
            //we exit the on state
            //the on-off led is off
            //the state led is off
            //the siren is off
            theUI->setLedState(1,0);
            theUI->setLedState(2,0);
            theAlert->setSiren(0);
            break;
        case ST_OFF:
            //reset the inner statemachine
            inner = ST_IDLE;
            break;
        }

        //do the eventual onentry-action of the new state
        switch (outer)
        {
        case ST_ON:
            //the on-off led is on
            theUI->setLedState(1,1);
            break;
        case ST_OFF:
            //no entry action
            break;
        }
    }
    //return the result of the event processing
    return retVal;
}

bool TrapController::processInnerEvent(XFEvent *p1)
{
    //save the actual state
    TC_TRAP_STATE oldState = inner;
    //hash the new state from the state table
    TC_TRAP_STATE newState = innerSM[oldState][(TC_TRAP_EVENT)p1->getID()];
    //if the hash table found a new state
    if (newState != ST_TRAP_NONE)
    {
        //save the new state
        inner = newState;
    }
    //we do not know if the event will be processed
    bool retVal = false;

    //if the new state is different from the old state
    if (inner != oldState)
    {
        //yes, we handled the event
        retVal = true;

        //perform all onexit-actions
        switch (oldState)
        {
        case ST_IDLE:
            //ST_IDLE has no onexit-action
           break;
        case ST_TRAPPING:
            //trapping has no onexit-action
             break;
        case ST_WARNING:
            //if we quit for trapping state
            //cancel running timeout
            //we allow  on-off
            if (inner == ST_TRAPPING)
            {
                timeout->cancel();
                theAlert->setLock(0);
            }
            //we stop the warning sound
            theAlert->setSiren(0);
            break;
        case ST_ALERT:
            //ST_ALERT has no onexit-action
            break;
        }

        //perform all onentry-actions
        switch (inner)
        {
        case ST_IDLE:
           //we switch the state led off
            //we switch the siren off
            //we allow on-off
            theUI->setLedState(2,0);
            theAlert->setSiren(0);
            theAlert->setLock(0);
            break;
        case ST_TRAPPING:
            //the state led is blinking slowly
            theUI->setLedState(2,2);
            break;
        case ST_WARNING:
            //start timeout of 10 seconds
            //the state led is blinking fast
            //the siren sounds warning
            //we disallow on-off
            XF::getInstance().pushEvent(timeout);
            theUI->setLedState(2,3);
            theAlert->setSiren(1);
            theAlert->setLock(1);
            break;
        case ST_ALERT:
             //th state led is on
            //the siren sounds alert
            theUI->setLedState(2,1);
            theAlert->setSiren(2);
            break;
        }

    }
    //return the result of the event processing
    return retVal;
}
