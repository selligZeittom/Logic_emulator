/*
 * Class PortLogicUI
 * This class is the gateway to the UI pakage.
 * It provides interfaces for the usage of the
 * leds and the buttons.
 * It has a connection to it's peer port PortUILogic
 * as well as a conection to the controller class
 * The controller class and it's peer port are connected to it,
 * but the port does not know this.
 *
 */

#ifndef PORTLOGICUI_H
#define PORTLOGICUI_H

#include "Interfaces/iled.h"
#include "Interfaces/ikey.h"

class PortUILogic;
class TrapController;

class PortLogicUI : public ILED, public IKey
{
public:
    PortLogicUI();
    virtual ~PortLogicUI();
    virtual void setLedState(int p1, int p2);
    virtual void onKeyPressed(int p1);
    void initRelations(PortUILogic* p1, TrapController* p2);
private:
    TrapController* theTC;
    PortUILogic* theUI;
};

#endif // PORTLOGICUI_H
