∞∞/*
 * Class TrapController
 * This class is the controller of the trap system.
 * It has a big statemachine doing all the logic.
 * It therefor is reactive and implements the ISM interface.
 * It has connections to the ports PortLogicUI and
 * PortLogicAlert. These ports are also connect to it, but
 * the controller does not know this.
 *
 */


#ifndef TRAPCONTROLLER_H
#define TRAPCONTROLLER_H

#include <map>
using namespace std;

class XFEVent;
#include "XF/ism.h"

class PortLogicAlert;
class PortLogicUI;

class TrapController : ISM
{
public:
    TrapController();
    virtual ~TrapController();
    void initRelations(PortLogicUI* p1, PortLogicAlert* p2);
    void onOnOffKey();
    void onArmKey();
    void onDisarmKey();
    void onResetKey();
    void onTestKey();
    void onActivated();

private:
    const int WARN_TIME;

    enum TC_ON_OFF_STATE
    {
        ST_ON_OFF_NONE, ST_ON=10, ST_OFF
    };
    enum TC_ON_OFF_EVENT
    {
        EV_ON_OFF_NONE, EV_ONOFF=100
    };
    enum TC_TRAP_STATE
    {
        ST_TRAP_NONE, ST_IDLE=20, ST_TRAPPING, ST_WARNING, ST_ALERT
    };
    enum TC_TRAP_EVENT
    {
        EV_TRAP_NONE, EV_ARM=200, EV_DISARM, EV_TIMEOUT, EV_TEST, EV_RESET, EV_ACTIVATE
    };

    TC_ON_OFF_STATE outer;
    TC_TRAP_STATE inner;

    map<TC_ON_OFF_STATE,map<TC_ON_OFF_EVENT,TC_ON_OFF_STATE>> outerSM;
    map<TC_TRAP_STATE,map<TC_TRAP_EVENT,TC_TRAP_STATE>> innerSM;

private:
    PortLogicAlert* theAlert;
    PortLogicUI* theUI;
    XFEvent* timeout;

    // ISM interface
public:
    bool processEvent(XFEvent* p1);
    bool processOuterEvent(XFEvent* p1);
    bool processInnerEvent(XFEvent* p1);
};

#endif // TRAPCONTROLLER_H
