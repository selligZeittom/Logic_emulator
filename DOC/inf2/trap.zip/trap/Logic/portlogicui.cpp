#include "portlogicui.h"
#include "UI/portuilogic.h"
#include "trapcontroller.h"

PortLogicUI::PortLogicUI()
{
    theUI = nullptr;
    theTC = nullptr;
}

PortLogicUI::~PortLogicUI()
{

}

void PortLogicUI::setLedState(int p1, int p2)
{
    //redirect request towards the UI port
    theUI->setLedState(p1,p2);
}

void PortLogicUI::onKeyPressed(int p1)
{
    //this switch transforms ids into
    //calls of corresponding handlers
    //this is a very hard coupling!!
    switch (p1)
    {
        case 1:
        theTC->onArmKey();
        break;
        case 2:
        theTC->onDisarmKey();
        break;
        case 3:
        theTC->onResetKey();
        break;
        case 4:
        theTC->onTestKey();
        break;
        case 5:
        theTC->onOnOffKey();
        break;
    default:;
    }
}

void PortLogicUI::initRelations(PortUILogic* p1, TrapController* p2)
{
    //connect the port to the UI port
    theUI = p1;
    //connect the port to the controller
    theTC = p2;
}
