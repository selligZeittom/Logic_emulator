#include "portlogicalert.h"
#include "Alert/portalertlogic.h"
#include "trapcontroller.h"

PortLogicAlert::PortLogicAlert()
{
    theAlert = nullptr;
    theTC = nullptr;
}

PortLogicAlert::~PortLogicAlert()
{

}

void PortLogicAlert::onActivated()
{
    //redirect the call from the alert port to the controller
    theTC->onActivated();
}

void PortLogicAlert::setSiren(int p1)
{
    //redirect the call from the controller to the alert port
    theAlert->setSiren(p1);
}

void PortLogicAlert::setLock(int p1)
{
    //redirect the call from the controller to the alert port
    theAlert->setLock(p1);
}

void PortLogicAlert::initRelations(PortAlertLogic* p1, TrapController* p2)
{
    //connect to the alert port
    theAlert = p1;
    //connect to the controller
    theTC = p2;
}
