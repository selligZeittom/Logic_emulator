#ifndef IBUTTON_H
#define IBUTTON_H


class IButton
{
public:
    IButton();
};

#endif // IBUTTON_H