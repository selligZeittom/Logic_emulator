#include "iviewupdate.h"

IViewUpdate::IViewUpdate()
{

}
