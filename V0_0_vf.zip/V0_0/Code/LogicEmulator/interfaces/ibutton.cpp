#include "ibutton.h"

IButton::IButton()
{

}
