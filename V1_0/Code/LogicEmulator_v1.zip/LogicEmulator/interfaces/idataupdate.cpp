#include "idataupdate.h"

IDataUpdate::IDataUpdate()
{

}
