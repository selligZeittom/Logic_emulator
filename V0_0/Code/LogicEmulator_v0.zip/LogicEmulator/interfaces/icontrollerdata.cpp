#include "icontrollerdata.h"

IControllerData::IControllerData()
{

}

